package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.cg.PatientException.PatientException;
import com.cg.bean.PatientBean;
import com.cg.util.DBConnection1;

public class PatientDAO implements IpatientDAO
{

	Logger logger=Logger.getRootLogger();
	public PatientDAO()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	
	
	public String addPatientDetails(PatientBean patientbean) throws PatientException 
	{
		Connection connection = DBConnection1.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		String patient_id=null;
		int queryResult=0;
		
		try
		{
			
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);
			preparedStatement.setString(1,patientbean.getPatient_name());			
			preparedStatement.setString(2,patientbean.getPhone());
			preparedStatement.setString(3,patientbean.getDescription());
			preparedStatement.setInt(4,patientbean.getAge());
			
			

			
			queryResult=preparedStatement.executeUpdate();
			

			preparedStatement = connection.prepareStatement(QueryMapper.PATIENTID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				patient_id=resultSet.getString(1);
						
			}
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new PatientException("Inserting patient details failed ");

			}
			else
			{
				logger.info("patient details added successfully:");
				return patient_id;
			}
		
		}
			catch(SQLException sqlException)
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new PatientException("Tehnical problem occured refer log");
			}
			finally
			{
				try 
				{
					//resultSet.close();
					preparedStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					sqlException.printStackTrace();
					logger.error(sqlException.getMessage());
					throw new PatientException("Error in closing db connection");

				}
			}
		}
		// TODO Auto-generated method stub
		
	

	
	public PatientBean viewPatientDetails(String PatientId) throws PatientException 
	{
		Connection connection=DBConnection1.getInstance().getConnection();

		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		PatientBean patientbean=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_PATIENT_DETAILS_QUERY);
			preparedStatement.setString(1,PatientId);
			resultset=preparedStatement.executeQuery();
			

			if(resultset.next())
			{
				patientbean = new PatientBean();
				
				patientbean.setPatient_name(resultset.getString(1));
				patientbean.setPhone(resultset.getString(2));
				patientbean.setDescription(resultset.getString(3));
				patientbean.setAge(resultset.getInt(4));
				//+patientbean.setDate(resultset.getDate(5));
				
				
			}
			
			if( patientbean != null)
			{
				logger.info("Record Found Successfully");
				return patientbean;
			}
			else
			{
				logger.info("Record Not Found Successfully");
				return null;
			}
		}
			
			catch(Exception e)
			{
				logger.error(e.getMessage());
				throw new PatientException(e.getMessage());
			}
			finally
			{
				try 
				{
					resultset.close();
					preparedStatement.close();
					connection.close();
				} 
				catch (SQLException e) 
				{
					logger.error(e.getMessage());
					throw new PatientException("Error in closing db connection");

				}
			}
			
		}




	public List<PatientBean> retriveAllDetails() throws PatientException 
	{
		Connection con=DBConnection1.getInstance().getConnection();
		int patientCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<PatientBean> patientList=new ArrayList<PatientBean>();
		
		try
		{
			ps=con.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
               PatientBean patientbean = new PatientBean();
				
				patientbean.setPatient_name(resultset.getString(1));
				patientbean.setPhone(resultset.getString(2));
				patientbean.setDescription(resultset.getString(3));
				patientbean.setAge(resultset.getInt(4));
				patientbean.setDate(resultset.getDate(5));
				//System.out.println(resultset.getString(1)+);
				patientList.add(patientbean);
				
				patientCount++;
			}		
			
		}
		catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new PatientException("Tehnical problem occured. Refer log");
		}
		
		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new PatientException("Error in closing db connection");

			}
		}
		if( patientCount == 0)
		return null;
		
		else
			return patientList;
	}
}	
		
	
	

	
	
	

	
	

